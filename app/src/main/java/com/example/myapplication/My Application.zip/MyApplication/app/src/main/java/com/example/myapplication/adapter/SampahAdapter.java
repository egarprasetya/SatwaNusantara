package com.example.myapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.model.ModelSampah;

import java.util.List;


public class SampahAdapter extends RecyclerView.Adapter<SampahAdapter.MyViewHolder> {
    private Context context;
    private List<ModelSampah> sampahList;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_volunteer_sampah, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ModelSampah model = sampahList.get(position);
        holder.kode.setText(model.getKodeSampah());
        holder.status.setText(model.getStatusVerifikasi());
        holder.ambil.setText(model.getTanggalSubmit());
        holder.berakhir.setText(model.getTanggalAkhir());
        Glide.with(context).load(model.getUrlFoto()).into(holder.foto);
    }

    @Override
    public int getItemCount() {
        return sampahList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView kode;
        public TextView status;
        public TextView ambil;
        public TextView berakhir;
        public ImageView foto;

        public MyViewHolder(View itemView) {
            super(itemView);
            kode = itemView.findViewById(R.id.volunteer_kode_sampah);
            status = itemView.findViewById(R.id.volunteer_status_sampah);
            ambil = itemView.findViewById(R.id.volunteer_ambil_sampah);
            berakhir = itemView.findViewById(R.id.volunteer_akhir_sampah);
            foto=itemView.findViewById(R.id.volunteer_gambar_sampah);
        }
    }

    public SampahAdapter(Context context, List<ModelSampah> sampahList) {
        this.context = context;
        this.sampahList = sampahList;
    }
}
