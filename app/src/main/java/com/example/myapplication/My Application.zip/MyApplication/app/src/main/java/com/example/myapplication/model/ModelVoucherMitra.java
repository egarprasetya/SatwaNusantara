package com.example.myapplication.model;

public class ModelVoucherMitra {
    private String namaMitra, poin, tanggalTukar;
    private String urlGambar;


    public ModelVoucherMitra() {
    }

}
