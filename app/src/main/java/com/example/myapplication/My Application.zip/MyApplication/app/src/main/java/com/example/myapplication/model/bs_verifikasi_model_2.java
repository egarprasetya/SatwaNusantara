package com.example.myapplication.model;

public class bs_verifikasi_model_2 {
    private String nama, level;

    public bs_verifikasi_model_2() {
    }

    public bs_verifikasi_model_2(String nama, String level) {
        this.nama = nama;
        this.level = level;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }
}
